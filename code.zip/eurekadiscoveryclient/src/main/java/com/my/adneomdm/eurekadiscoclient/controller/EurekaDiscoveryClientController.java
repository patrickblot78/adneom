package com.my.adneomdm.eurekadiscoclient.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EurekaDiscoveryClientController {
	@GetMapping("/hello")
	public String sayHello() {
		return "hello";
	}
	
	@GetMapping(
			value = "/array", 
			params = { "tablo", "nombre" })
	@ResponseBody
	public String arrayTraitement(
			@RequestParam("tablo") String tablo, 
			@RequestParam("nombre") Integer nombre) {
		if(nombre!=null && tablo.length()>0) return partition(new ArrayList<String>(Arrays.asList(tablo.split(","))), nombre).toString();
		else return "[]";
	}

	public static List<List<String>> partition(List<String> lst, Integer nbre ){
		List<List<String>> al2 = new ArrayList<>();
		if(nbre!=null && nbre>0 && lst!=null && lst.size()>0) {
			if(lst.size()>nbre) {
				int size = lst.size();
				int mod = size%nbre;
				int iter = (size-mod)/nbre;
				for(int j=0;j<iter;j++) {
					List<String> al = new ArrayList<>();
					for(int k=j*nbre;k<j*nbre+nbre;k++) {
						al.add(lst.get(k));
					}
					al2.add(al);
				}
				if(mod>0) {
					List<String> al = new ArrayList<>();
					for(int i=size-mod;i<size;i++) {
						al.add(lst.get(i));
					}
					al2.add(al);
				}
			}else al2.add(new ArrayList<String>(lst));
		}
		return al2;		
	}
}
