package com.my.adneomdm.eurekadiscoclient.controller;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.my.adneomdm.eurekadiscoclient.EurekaDiscoveryClientApplication;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = EurekaDiscoveryClientController.class)
public class EurekaDiscoveryClientControllerTest {
	
	
	@Test
	public void contextLoads() {
	}
    
    @Test
	public void testArray() {
		SpringApplication.run(EurekaDiscoveryClientApplication.class, new String[]{""});
		HttpHeaders headers = new HttpHeaders();
		HttpEntity<String> entity = new HttpEntity<String>(null, headers);
		ResponseEntity<String> response = new TestRestTemplate().exchange("http://localhost:8000/array?tablo=1,2,3,4,5,6,7,8,9&nombre=2", 
				HttpMethod.GET, entity, String.class);
		ResponseEntity<String> response2 = new TestRestTemplate().exchange("http://localhost:8000/array?tablo=&nombre=2", 
				HttpMethod.GET, entity, String.class);
		ResponseEntity<String> response3 = new TestRestTemplate().exchange("http://localhost:8000/array?tablo=&nombre=0", 
				HttpMethod.GET, entity, String.class);
		ResponseEntity<String> response4 = new TestRestTemplate().exchange("http://localhost:8000/array?tablo=&nombre=", 
				HttpMethod.GET, entity, String.class);
		Assert.assertEquals(response.getBody(), "[[1, 2], [3, 4], [5, 6], [7, 8], [9]]");
		Assert.assertEquals(response2.getBody(), "[]");
		Assert.assertEquals(response3.getBody(), "[]");
		Assert.assertEquals(response4.getBody(), "[]");
	}
}
