package com.my.adneomdm.eurekaribbon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.netflix.ribbon.RibbonClient;

import com.my.adneomdm.eurekaribbon.config.RibbonConfiguration;

@RibbonClient(name = "ping-server", configuration = RibbonConfiguration.class)
@EnableEurekaClient
@SpringBootApplication
public class EurekaRibbonApplication {

	public static void main(String[] args) {
		SpringApplication.run(EurekaRibbonApplication.class, args);
	}

}
