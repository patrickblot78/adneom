package com.my.adneomdm.eurekaribbon.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.loadbalancer.LoadBalancerClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.netflix.appinfo.InstanceInfo;
import com.netflix.discovery.DiscoveryClient;

@RestController
public class EurekaRibbonController {
	
    @Autowired
    private LoadBalancerClient loadBalancer;
 
    @ResponseBody
    @GetMapping(value = "/array", params = { "tablo", "nombre" })
    public String testArray( 
    	@RequestParam("tablo") String tablo, 
    	@RequestParam("nombre") String nombre){
 
        String serviceId = "MY-SERVICE".toLowerCase();
        String html = "";
        
        RestTemplate restTemplate = new RestTemplate();
 
        try {
	            ServiceInstance serviceInstance = this.loadBalancer.choose(serviceId);
 	            String url = "http://" + serviceInstance.getHost() + ":" + serviceInstance.getPort() + "/array?tablo="+tablo+"&nombre="+nombre;
	            html += "<br>Call: " + url;
	            html += "<br>";
	            
	            String result = restTemplate.getForObject(url, String.class);
	            html += "<br>Reponse du serveur: \"" + result+"\"";
        } catch (IllegalStateException e) {
            html += "<br>loadBalancer.choose ERROR: " + e.getMessage();
            e.printStackTrace();
        } catch (Exception e) {
            html += "<br>ERROR: " + e.getMessage();
            e.printStackTrace();
        }
        return html;
    }
    
}
